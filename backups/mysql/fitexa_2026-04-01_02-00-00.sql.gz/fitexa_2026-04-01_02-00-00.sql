-- MySQL dump 10.13  Distrib 8.4.8, for Linux (x86_64)
--
-- Host: mysql    Database: fitexa
-- ------------------------------------------------------
-- Server version	8.4.8

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activities`
--

DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activities` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(140) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activities`
--

LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
INSERT INTO `activities` VALUES (3,'Musculacion','Entrenamiento de fuerza y acondicionamiento en sala.'),(4,'Funcional','Clases dinamicas de fuerza, movilidad y resistencia.'),(5,'Crossfit','Entrenamientos intensos de fuerza, tecnica y condicion fisica.'),(6,'Yoga','Practicas guiadas de movilidad, respiracion y control corporal.'),(7,'Pilates','Trabajo de estabilidad, postura y control del movimiento.'),(8,'Boxeo','Clases tecnicas y de acondicionamiento con foco en boxeo.'),(9,'Spinning','Clases de ciclismo indoor por objetivos de resistencia.');
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exercise_personal_record_entries`
--

DROP TABLE IF EXISTS `exercise_personal_record_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exercise_personal_record_entries` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `exercise_id` bigint NOT NULL,
  `weight` double NOT NULL,
  `recorded_at` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_exercise_personal_record_entries_user` (`user_id`),
  KEY `fk_exercise_personal_record_entries_exercise` (`exercise_id`),
  CONSTRAINT `fk_exercise_personal_record_entries_exercise` FOREIGN KEY (`exercise_id`) REFERENCES `exercises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_exercise_personal_record_entries_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exercise_personal_record_entries`
--

LOCK TABLES `exercise_personal_record_entries` WRITE;
/*!40000 ALTER TABLE `exercise_personal_record_entries` DISABLE KEYS */;
INSERT INTO `exercise_personal_record_entries` VALUES (1,10,2,60,'2026-03-14'),(2,10,2,65,'2026-03-22'),(3,10,3,24,'2026-03-24'),(4,10,5,55,'2026-03-27'),(5,11,13,1,'2026-03-18'),(6,12,8,120,'2026-03-20'),(7,12,7,85,'2026-03-25'),(8,13,3,14,'2026-03-28'),(9,14,2,55,'2026-03-23'),(10,16,11,50,'2026-03-26');
/*!40000 ALTER TABLE `exercise_personal_record_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exercise_personal_records`
--

DROP TABLE IF EXISTS `exercise_personal_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exercise_personal_records` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `exercise_id` bigint NOT NULL,
  `max_weight` double NOT NULL,
  `recorded_at` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_exercise_personal_records_user_exercise` (`user_id`,`exercise_id`),
  KEY `fk_exercise_personal_records_exercise` (`exercise_id`),
  CONSTRAINT `fk_exercise_personal_records_exercise` FOREIGN KEY (`exercise_id`) REFERENCES `exercises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_exercise_personal_records_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exercise_personal_records`
--

LOCK TABLES `exercise_personal_records` WRITE;
/*!40000 ALTER TABLE `exercise_personal_records` DISABLE KEYS */;
INSERT INTO `exercise_personal_records` VALUES (1,10,2,65,'2026-03-22'),(2,10,3,24,'2026-03-24'),(3,10,5,55,'2026-03-27'),(4,11,13,1,'2026-03-18'),(5,12,8,120,'2026-03-20'),(6,12,7,85,'2026-03-25'),(7,13,3,14,'2026-03-28'),(8,14,2,55,'2026-03-23'),(9,16,11,50,'2026-03-26');
/*!40000 ALTER TABLE `exercise_personal_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exercises`
--

DROP TABLE IF EXISTS `exercises`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exercises` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(140) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activity_id` bigint DEFAULT NULL,
  `machine_id` bigint DEFAULT NULL,
  `video_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_exercises_activity` (`activity_id`),
  KEY `fk_exercises_machine` (`machine_id`),
  CONSTRAINT `fk_exercises_activity` FOREIGN KEY (`activity_id`) REFERENCES `activities` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_exercises_machine` FOREIGN KEY (`machine_id`) REFERENCES `machines` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exercises`
--

LOCK TABLES `exercises` WRITE;
/*!40000 ALTER TABLE `exercises` DISABLE KEYS */;
INSERT INTO `exercises` VALUES (2,'Press banca con barra',3,4,'https://www.youtube.com/watch?v=rT7DgCr-3pg'),(3,'Press inclinado con mancuernas',3,2,'https://www.youtube.com/watch?v=8iPEnn-ltC8'),(4,'Aperturas con mancuernas',3,2,'https://www.youtube.com/watch?v=eozdVDA78K0'),(5,'Remo sentado en polea',3,7,'https://www.youtube.com/watch?v=GZbfZ033f74'),(6,'Jalon al pecho',3,5,'https://www.youtube.com/watch?v=CAwf7n6Luuc'),(7,'Peso muerto rumano',3,3,'https://www.youtube.com/watch?v=2SHsk9AzdjA'),(8,'Prensa 45',3,6,'https://www.youtube.com/watch?v=IZxyjW7MPJQ'),(9,'Sentadilla goblet',4,2,'https://www.youtube.com/watch?v=6xwGFn-J_Qw'),(10,'Caminata en cinta inclinada',4,11,'https://www.youtube.com/watch?v=_kLBi8tF6K4'),(11,'Thruster con barra',5,3,'https://www.youtube.com/watch?v=L219ltL15zk'),(12,'Remo metabolico',5,7,'https://www.youtube.com/watch?v=7cPhKwRF0fI'),(13,'Trabajo en reformer',7,10,'https://www.youtube.com/watch?v=E9fR9X0x8v8'),(14,'Bolsa tecnica 3 rounds',8,9,'https://www.youtube.com/watch?v=9hC5x7X1lE0'),(15,'Bloque de resistencia 45 min',9,8,'https://www.youtube.com/watch?v=F1B9Fk_SgI0'),(16,'Saludo al sol guiado',6,NULL,'https://www.youtube.com/watch?v=6IUy0g7cY8s');
/*!40000 ALTER TABLE `exercises` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gym_class_days`
--

DROP TABLE IF EXISTS `gym_class_days`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gym_class_days` (
  `gym_class_id` bigint NOT NULL,
  `day` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`gym_class_id`,`day`),
  CONSTRAINT `fk_class_days_class` FOREIGN KEY (`gym_class_id`) REFERENCES `gym_classes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gym_class_days`
--

LOCK TABLES `gym_class_days` WRITE;
/*!40000 ALTER TABLE `gym_class_days` DISABLE KEYS */;
INSERT INTO `gym_class_days` VALUES (2,'LUNES'),(2,'MIERCOLES'),(2,'VIERNES'),(3,'JUEVES'),(3,'MARTES'),(4,'LUNES'),(4,'MIERCOLES'),(5,'JUEVES'),(5,'MARTES'),(6,'JUEVES'),(6,'MARTES'),(7,'LUNES'),(7,'MIERCOLES'),(7,'VIERNES'),(8,'LUNES'),(8,'MIERCOLES');
/*!40000 ALTER TABLE `gym_class_days` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gym_class_subscriptions`
--

DROP TABLE IF EXISTS `gym_class_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gym_class_subscriptions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `gym_class_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `target_date` date NOT NULL,
  `subscribed_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `attendance_present` tinyint(1) DEFAULT NULL,
  `attendance_marked_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_gym_class_subscriptions_class_user_date` (`gym_class_id`,`user_id`,`target_date`),
  KEY `fk_class_subscriptions_user` (`user_id`),
  CONSTRAINT `fk_class_subscriptions_class` FOREIGN KEY (`gym_class_id`) REFERENCES `gym_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_class_subscriptions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gym_class_subscriptions`
--

LOCK TABLES `gym_class_subscriptions` WRITE;
/*!40000 ALTER TABLE `gym_class_subscriptions` DISABLE KEYS */;
INSERT INTO `gym_class_subscriptions` VALUES (2,7,10,'2026-03-16','2026-03-16 09:15:00',1,'2026-03-16 19:05:00'),(3,7,10,'2026-03-18','2026-03-18 09:15:00',1,'2026-03-18 19:07:00'),(4,7,10,'2026-03-23','2026-03-23 09:20:00',1,'2026-03-23 19:03:00'),(5,7,10,'2026-03-25','2026-03-25 09:20:00',0,'2026-03-25 19:10:00'),(6,7,10,'2026-03-30','2026-03-30 09:10:00',1,'2026-03-30 19:02:00'),(7,2,16,'2026-03-16','2026-03-16 07:30:00',1,'2026-03-16 09:01:00'),(8,2,16,'2026-03-20','2026-03-20 07:30:00',1,'2026-03-20 09:00:00'),(9,2,16,'2026-03-23','2026-03-23 07:32:00',1,'2026-03-23 09:01:00'),(10,2,16,'2026-03-27','2026-03-27 07:32:00',0,'2026-03-27 09:04:00'),(11,2,16,'2026-03-30','2026-03-30 07:35:00',1,'2026-03-30 09:02:00'),(12,3,11,'2026-03-17','2026-03-17 10:10:00',1,'2026-03-17 20:02:00'),(13,3,11,'2026-03-19','2026-03-19 10:10:00',1,'2026-03-19 20:01:00'),(14,3,11,'2026-03-24','2026-03-24 10:12:00',1,'2026-03-24 20:00:00'),(15,3,11,'2026-03-26','2026-03-26 10:12:00',1,'2026-03-26 20:00:00'),(16,4,11,'2026-03-23','2026-03-23 08:25:00',1,'2026-03-23 11:03:00'),(17,4,15,'2026-03-25','2026-03-25 08:30:00',1,'2026-03-25 11:02:00'),(18,4,15,'2026-03-30','2026-03-30 08:30:00',0,'2026-03-30 11:00:00'),(19,5,12,'2026-03-17','2026-03-17 15:00:00',1,'2026-03-17 21:04:00'),(20,5,12,'2026-03-19','2026-03-19 15:00:00',1,'2026-03-19 21:02:00'),(21,5,12,'2026-03-24','2026-03-24 15:10:00',1,'2026-03-24 21:05:00'),(22,6,13,'2026-03-17','2026-03-17 11:20:00',1,'2026-03-17 19:03:00'),(23,6,13,'2026-03-19','2026-03-19 11:20:00',1,'2026-03-19 19:00:00'),(24,6,13,'2026-03-24','2026-03-24 11:25:00',1,'2026-03-24 19:01:00'),(25,8,14,'2026-03-16','2026-03-16 10:00:00',1,'2026-03-16 14:00:00'),(26,8,14,'2026-03-18','2026-03-18 10:00:00',1,'2026-03-18 14:01:00'),(27,8,14,'2026-03-23','2026-03-23 10:02:00',1,'2026-03-23 14:02:00'),(28,8,17,'2026-03-25','2026-03-25 10:05:00',1,'2026-03-25 14:00:00'),(29,7,14,'2026-03-27','2026-03-27 11:00:00',1,'2026-03-27 19:05:00'),(30,3,17,'2026-03-26','2026-03-26 11:00:00',1,'2026-03-26 20:00:00'),(31,7,10,'2026-04-01','2026-04-01 09:30:00',NULL,NULL),(32,5,12,'2026-04-02','2026-04-01 09:35:00',NULL,NULL),(33,6,13,'2026-04-02','2026-04-01 09:35:00',NULL,NULL),(34,2,16,'2026-04-01','2026-04-01 08:00:00',NULL,NULL),(35,3,11,'2026-04-02','2026-04-01 08:10:00',NULL,NULL),(36,4,15,'2026-04-01','2026-04-01 08:10:00',NULL,NULL),(37,8,17,'2026-04-01','2026-04-01 08:20:00',NULL,NULL),(38,7,14,'2026-04-03','2026-04-01 09:00:00',NULL,NULL),(39,7,10,'2026-04-06','2026-04-01 09:45:00',NULL,NULL),(40,2,16,'2026-04-06','2026-04-01 09:45:00',NULL,NULL),(41,6,13,'2026-04-07','2026-04-01 09:45:00',NULL,NULL),(42,8,14,'2026-04-01','2026-04-01 02:41:09',NULL,NULL),(43,8,14,'2026-04-06','2026-04-01 02:46:51',NULL,NULL),(44,8,14,'2026-04-08','2026-04-01 02:55:05',NULL,NULL),(45,7,14,'2026-04-10','2026-04-01 04:32:33',NULL,NULL);
/*!40000 ALTER TABLE `gym_class_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gym_classes`
--

DROP TABLE IF EXISTS `gym_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gym_classes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `class_name` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activity_id` bigint DEFAULT NULL,
  `max_capacity` int DEFAULT NULL,
  `enrolled` int NOT NULL DEFAULT '0',
  `teacher_id` bigint DEFAULT NULL,
  `date` date NOT NULL,
  `all_day` tinyint(1) NOT NULL DEFAULT '0',
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_classes_activity` (`activity_id`),
  KEY `fk_classes_teacher` (`teacher_id`),
  CONSTRAINT `fk_classes_activity` FOREIGN KEY (`activity_id`) REFERENCES `activities` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_classes_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gym_classes`
--

LOCK TABLES `gym_classes` WRITE;
/*!40000 ALTER TABLE `gym_classes` DISABLE KEYS */;
INSERT INTO `gym_classes` VALUES (2,'Crossfit Morning',5,18,0,4,'2026-03-04',0,'08:00:00','09:00:00'),(3,'Yoga Flow',6,20,0,6,'2026-03-04',0,'19:00:00','20:00:00'),(4,'Pilates Control',7,14,0,6,'2026-03-04',0,'10:00:00','11:00:00'),(5,'Box Funcional',8,16,0,5,'2026-03-04',0,'20:00:00','21:00:00'),(6,'Spinning Power',9,24,0,7,'2026-03-04',0,'18:00:00','19:00:00'),(7,'Musculacion Guiada',3,18,0,4,'2026-03-04',0,'18:00:00','19:00:00'),(8,'Funcional Noon',4,16,0,5,'2026-03-04',0,'13:00:00','14:00:00');
/*!40000 ALTER TABLE `gym_classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `machines`
--

DROP TABLE IF EXISTS `machines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `machines` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(140) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL DEFAULT '1',
  `photo_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `machines`
--

LOCK TABLES `machines` WRITE;
/*!40000 ALTER TABLE `machines` DISABLE KEYS */;
INSERT INTO `machines` VALUES (2,'Mancuernas',10,'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&w=900&q=80'),(3,'Barra Olimpica',6,'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=900&q=80'),(4,'Banco Plano',4,'https://images.unsplash.com/photo-1579758629938-03607ccdbaba?auto=format&fit=crop&w=900&q=80'),(5,'Polea Alta',3,'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?auto=format&fit=crop&w=900&q=80'),(6,'Prensa 45',2,'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=900&q=80'),(7,'Remo Bajo',2,'https://images.unsplash.com/photo-1598971639058-fab3c3109a00?auto=format&fit=crop&w=900&q=80'),(8,'Bicicleta Spinning',12,'https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=900&q=80'),(9,'Bolsa de Boxeo',4,'https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?auto=format&fit=crop&w=900&q=80'),(10,'Reformer',6,'https://images.unsplash.com/photo-1518310383802-640c2de311b2?auto=format&fit=crop&w=900&q=80'),(11,'Cinta',5,'https://images.unsplash.com/photo-1599058917765-a780eda07a3e?auto=format&fit=crop&w=900&q=80');
/*!40000 ALTER TABLE `machines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plans`
--

DROP TABLE IF EXISTS `plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plans` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `max_days_per_week` int NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plans`
--

LOCK TABLES `plans` WRITE;
/*!40000 ALTER TABLE `plans` DISABLE KEYS */;
INSERT INTO `plans` VALUES (4,'Plan Libre',42000.00,7,1),(5,'Plan 4 veces',36000.00,4,1),(6,'Plan 3 veces',32000.00,3,1),(7,'Plan 2 veces',28000.00,2,1);
/*!40000 ALTER TABLE `plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_menu_permissions`
--

DROP TABLE IF EXISTS `role_menu_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_menu_permissions` (
  `role_id` bigint NOT NULL,
  `menu_item` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`role_id`,`menu_item`),
  CONSTRAINT `fk_role_menu_permissions_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_menu_permissions`
--

LOCK TABLES `role_menu_permissions` WRITE;
/*!40000 ALTER TABLE `role_menu_permissions` DISABLE KEYS */;
INSERT INTO `role_menu_permissions` VALUES (1,'ACTIVITIES'),(1,'AGENDA'),(1,'CLASSES'),(1,'DASHBOARD'),(1,'EXERCISES'),(1,'MACHINES'),(1,'PLANS'),(1,'ROLES_PERMISSIONS'),(1,'ROUTINES'),(1,'USERS'),(2,'ACTIVITIES'),(2,'AGENDA'),(2,'CLASSES'),(2,'EXERCISES'),(2,'MACHINES'),(2,'PLANS'),(2,'ROUTINES'),(2,'USERS'),(4,'EXERCISES'),(4,'MACHINES'),(4,'ROUTINES'),(5,'AGENDA'),(5,'CLASSES'),(5,'PLANS'),(5,'USERS'),(6,'ACTIVITIES'),(6,'AGENDA'),(6,'CLASSES'),(6,'DASHBOARD'),(6,'EXERCISES'),(6,'MACHINES'),(6,'PLANS'),(6,'ROUTINES'),(6,'USERS');
/*!40000 ALTER TABLE `role_menu_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `system_role` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Administrador','Acceso completo al panel de administracion.',1),(2,'Profesor','Acceso al panel operativo excepto dashboard y roles y permisos.',1),(3,'Alumno','Rol base sin acceso visible al panel de administracion.',1),(4,'PROFESOR 2','Encargado de crear rutinas',0),(5,'Recepcion','Rol operativo para recepcion y atencion diaria.',0),(6,'Coordinacion','Rol de coordinacion para seguimiento comercial y operativo.',0);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `routine_assignment_days`
--

DROP TABLE IF EXISTS `routine_assignment_days`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `routine_assignment_days` (
  `routine_assignment_id` bigint NOT NULL,
  `day` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`routine_assignment_id`,`day`),
  CONSTRAINT `fk_ra_days_assignment` FOREIGN KEY (`routine_assignment_id`) REFERENCES `routine_assignments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `routine_assignment_days`
--

LOCK TABLES `routine_assignment_days` WRITE;
/*!40000 ALTER TABLE `routine_assignment_days` DISABLE KEYS */;
INSERT INTO `routine_assignment_days` VALUES (2,'LUNES'),(2,'MIERCOLES'),(3,'VIERNES'),(4,'JUEVES'),(4,'MARTES'),(5,'LUNES'),(5,'MIERCOLES'),(5,'VIERNES'),(6,'JUEVES'),(6,'MARTES'),(7,'LUNES'),(7,'MIERCOLES'),(7,'VIERNES'),(8,'JUEVES'),(8,'LUNES'),(9,'LUNES'),(9,'MIERCOLES'),(9,'VIERNES');
/*!40000 ALTER TABLE `routine_assignment_days` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `routine_assignment_exercises`
--

DROP TABLE IF EXISTS `routine_assignment_exercises`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `routine_assignment_exercises` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `assignment_id` bigint NOT NULL,
  `exercise_id` bigint NOT NULL,
  `exercise_name` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sets` int NOT NULL,
  `prescription_mode` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reps` int DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `min_reps` int DEFAULT NULL,
  `max_reps` int DEFAULT NULL,
  `min_weight` double DEFAULT NULL,
  `max_weight` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_rae_assignment` (`assignment_id`),
  KEY `fk_rae_exercise` (`exercise_id`),
  CONSTRAINT `fk_rae_assignment` FOREIGN KEY (`assignment_id`) REFERENCES `routine_assignments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rae_exercise` FOREIGN KEY (`exercise_id`) REFERENCES `exercises` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `routine_assignment_exercises`
--

LOCK TABLES `routine_assignment_exercises` WRITE;
/*!40000 ALTER TABLE `routine_assignment_exercises` DISABLE KEYS */;
INSERT INTO `routine_assignment_exercises` VALUES (2,2,2,'Press banca con barra',4,'FIJO',8,65,NULL,NULL,NULL,NULL),(3,2,3,'Press inclinado con mancuernas',4,'FIJO',10,24,NULL,NULL,NULL,NULL),(4,2,4,'Aperturas con mancuernas',3,'DINAMICO',NULL,NULL,12,15,10,14),(5,3,5,'Remo sentado en polea',4,'FIJO',10,55,NULL,NULL,NULL,NULL),(6,3,6,'Jalon al pecho',4,'FIJO',10,50,NULL,NULL,NULL,NULL),(7,3,7,'Peso muerto rumano',3,'FIJO',8,75,NULL,NULL,NULL,NULL),(8,4,10,'Caminata en cinta inclinada',3,'DINAMICO',NULL,NULL,12,15,NULL,NULL),(9,4,13,'Trabajo en reformer',4,'FIJO',12,NULL,NULL,NULL,NULL,NULL),(10,4,12,'Remo metabolico',3,'DINAMICO',NULL,NULL,8,12,NULL,NULL),(11,5,8,'Prensa 45',4,'FIJO',10,120,NULL,NULL,NULL,NULL),(12,5,9,'Sentadilla goblet',3,'FIJO',12,26,NULL,NULL,NULL,NULL),(13,5,7,'Peso muerto rumano',4,'FIJO',8,85,NULL,NULL,NULL,NULL),(14,6,9,'Sentadilla goblet',3,'FIJO',12,18,NULL,NULL,NULL,NULL),(15,6,10,'Caminata en cinta inclinada',3,'DINAMICO',NULL,NULL,15,20,NULL,NULL),(16,6,3,'Press inclinado con mancuernas',3,'FIJO',10,14,NULL,NULL,NULL,NULL),(17,7,9,'Sentadilla goblet',4,'FIJO',10,24,NULL,NULL,NULL,NULL),(18,7,10,'Caminata en cinta inclinada',3,'DINAMICO',NULL,NULL,12,18,NULL,NULL),(19,7,2,'Press banca con barra',4,'FIJO',8,55,NULL,NULL,NULL,NULL),(20,8,13,'Trabajo en reformer',4,'FIJO',12,NULL,NULL,NULL,NULL,NULL),(21,8,10,'Caminata en cinta inclinada',3,'DINAMICO',NULL,NULL,15,18,NULL,NULL),(22,8,12,'Remo metabolico',3,'DINAMICO',NULL,NULL,8,10,NULL,NULL),(23,9,11,'Thruster con barra',5,'FIJO',6,50,NULL,NULL,NULL,NULL),(24,9,5,'Remo sentado en polea',4,'FIJO',10,60,NULL,NULL,NULL,NULL),(25,9,3,'Press inclinado con mancuernas',4,'FIJO',10,26,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `routine_assignment_exercises` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `routine_assignments`
--

DROP TABLE IF EXISTS `routine_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `routine_assignments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `routine_template_id` bigint DEFAULT NULL,
  `custom_name` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_ra_template` (`routine_template_id`),
  KEY `idx_ra_user_dates` (`user_id`,`start_date`,`end_date`),
  CONSTRAINT `fk_ra_template` FOREIGN KEY (`routine_template_id`) REFERENCES `routine_templates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ra_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `routine_assignments`
--

LOCK TABLES `routine_assignments` WRITE;
/*!40000 ALTER TABLE `routine_assignments` DISABLE KEYS */;
INSERT INTO `routine_assignments` VALUES (2,10,2,NULL,'2026-03-04','2026-04-15'),(3,10,3,NULL,'2026-03-04','2026-04-15'),(4,11,6,NULL,'2026-03-11','2026-04-22'),(5,12,4,NULL,'2026-03-04','2026-04-08'),(6,13,5,NULL,'2026-03-18','2026-04-22'),(7,14,5,NULL,'2026-03-11','2026-04-15'),(8,15,6,NULL,'2026-02-25','2026-03-27'),(9,16,NULL,'Rutina Custom Competencia','2026-03-18','2026-04-15');
/*!40000 ALTER TABLE `routine_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `routine_template_exercises`
--

DROP TABLE IF EXISTS `routine_template_exercises`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `routine_template_exercises` (
  `routine_template_id` bigint NOT NULL,
  `exercise_id` bigint NOT NULL,
  PRIMARY KEY (`routine_template_id`,`exercise_id`),
  KEY `fk_rt_ex_exercise` (`exercise_id`),
  CONSTRAINT `fk_rt_ex_exercise` FOREIGN KEY (`exercise_id`) REFERENCES `exercises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rt_ex_template` FOREIGN KEY (`routine_template_id`) REFERENCES `routine_templates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `routine_template_exercises`
--

LOCK TABLES `routine_template_exercises` WRITE;
/*!40000 ALTER TABLE `routine_template_exercises` DISABLE KEYS */;
INSERT INTO `routine_template_exercises` VALUES (2,2),(2,3),(5,3),(2,4),(3,5),(3,6),(3,7),(4,7),(4,8),(4,9),(5,9),(5,10),(6,10),(6,12),(6,13);
/*!40000 ALTER TABLE `routine_template_exercises` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `routine_templates`
--

DROP TABLE IF EXISTS `routine_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `routine_templates` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `routine_templates`
--

LOCK TABLES `routine_templates` WRITE;
/*!40000 ALTER TABLE `routine_templates` DISABLE KEYS */;
INSERT INTO `routine_templates` VALUES (2,'Empuje Superior','2026-02-15'),(3,'Espalda y Traccion','2026-02-15'),(4,'Piernas y Potencia','2026-02-20'),(5,'Full Body Funcional','2026-02-25'),(6,'Core y Resistencia','2026-03-12');
/*!40000 ALTER TABLE `routine_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_activities`
--

DROP TABLE IF EXISTS `user_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_activities` (
  `user_id` bigint NOT NULL,
  `activity_id` bigint NOT NULL,
  PRIMARY KEY (`user_id`,`activity_id`),
  KEY `fk_user_activities_activity` (`activity_id`),
  CONSTRAINT `fk_user_activities_activity` FOREIGN KEY (`activity_id`) REFERENCES `activities` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_user_activities_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_activities`
--

LOCK TABLES `user_activities` WRITE;
/*!40000 ALTER TABLE `user_activities` DISABLE KEYS */;
INSERT INTO `user_activities` VALUES (10,3),(14,3),(16,3),(12,4),(14,4),(17,4),(10,5),(16,5),(11,6),(13,6),(17,6),(11,7),(15,7),(17,7),(12,8),(16,8),(13,9),(15,9);
/*!40000 ALTER TABLE `user_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_payment_movements`
--

DROP TABLE IF EXISTS `user_payment_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_payment_movements` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `plan_id` bigint DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL,
  `detail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `paid_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_user_payment_movements_user` (`user_id`),
  KEY `fk_user_payment_movements_plan` (`plan_id`),
  CONSTRAINT `fk_user_payment_movements_plan` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_user_payment_movements_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_payment_movements`
--

LOCK TABLES `user_payment_movements` WRITE;
/*!40000 ALTER TABLE `user_payment_movements` DISABLE KEYS */;
INSERT INTO `user_payment_movements` VALUES (2,10,4,42000.00,'Renovacion de cuota','2026-03-12 10:12:00'),(3,10,4,42000.00,'Renovacion de cuota','2026-02-10 09:05:00'),(4,11,6,32000.00,'Renovacion de cuota','2026-03-08 11:10:00'),(5,12,5,36000.00,'Renovacion de cuota','2026-03-14 12:22:00'),(6,13,7,28000.00,'Renovacion de cuota','2026-03-05 16:45:00'),(7,14,6,32000.00,'Renovacion de cuota','2026-03-03 18:30:00'),(8,16,4,42000.00,'Renovacion de cuota','2026-03-23 08:40:00'),(9,15,7,28000.00,'Pago parcial pendiente de regularizacion','2026-02-26 14:15:00'),(10,17,5,36000.00,'Pago recibido fuera de termino','2026-02-19 13:05:00');
/*!40000 ALTER TABLE `user_payment_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `first_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dni` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `must_change_password` tinyint(1) NOT NULL DEFAULT '0',
  `birth_date` date NOT NULL,
  `user_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` bigint DEFAULT NULL,
  `plan_id` bigint DEFAULT NULL,
  `registration_date` date NOT NULL,
  `renewal_date` date NOT NULL,
  `payment_status` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dni` (`dni`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_users_plan` (`plan_id`),
  KEY `fk_users_role` (`role_id`),
  CONSTRAINT `fk_users_plan` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin','Fitexa','00000000','Sin direccion','0000000000','admin@fitexa.com','$2a$10$qZnbpykMIKuUiGahe6hzTu8JISGpAAHGMEiE9a6lipXjvR9QgnR8O',0,'1990-01-01','ADMIN',1,NULL,'2026-03-25','2099-12-31','AL_DIA'),(4,'Lucia','Gimenez','30111222','Av. Libertador 1450','1130000001','lucia.gimenez@fitexa.com','$2a$10$OYQj9E8HbzUuNtzmhI2bzOVKRT0ewOwwYI2VM93uHvbtsEztMurAm',0,'1989-04-12','PROFESOR',2,NULL,'2025-02-05','2027-04-01','AL_DIA'),(5,'Diego','Ferrero','29888777','Olleros 845','1130000002','diego.ferrero@fitexa.com','$2a$10$x5LYmGNnflLEcx/jcsZA5.kpuicya6gvIvmU6vp47ULx2PAwTJdVW',0,'1987-08-21','PROFESOR',2,NULL,'2025-03-07','2027-04-01','AL_DIA'),(6,'Carla','Ibanez','31222444','Migueletes 1120','1130000003','carla.ibanez@fitexa.com','$2a$10$isqfFNR8tgSNAu6Br8KrGe8u1e.8D2EsSUZJ/.5L39ZoC3TDCPL4m',0,'1991-02-09','PROFESOR',2,NULL,'2025-04-06','2027-04-01','AL_DIA'),(7,'Pablo','Rossi','28999111','La Pampa 2130','1130000004','pablo.rossi@fitexa.com','$2a$10$Lfe7o1W3r9iHPQ8robXbJ.MKVzCOf50TXMyl7jM2D0ABI1aLEl5h.',0,'1985-11-17','PROFESOR',2,NULL,'2024-10-28','2027-04-01','AL_DIA'),(8,'Sofia','Mendez','33555111','Quesada 980','1130000005','sofia.mendez@fitexa.com','$2a$10$MtYXT.14viyH80oWD6nRb.ltBGYzFUdlGo3wDbbtyQFIZiMu9r4Oq',0,'1993-05-20','PROFESOR',5,NULL,'2025-09-03','2027-04-01','AL_DIA'),(9,'Tomas','Suarez','32777111','Mendoza 440','1130000006','tomas.suarez@fitexa.com','$2a$10$h4c/ESEhex52NPP/WptRuu68Gj0LWQezVMjlXC9mF/80yDcUmAb4O',0,'1990-09-14','PROFESOR',6,NULL,'2025-10-03','2027-04-01','AL_DIA'),(10,'Maxi','Roselli','35123123','Juramento 2211','1144441001','maxiroselli@gmail.com','$2a$10$xzKw/a6FObhtNKuFYEbWOeECVEYb5xPyt3u3p9sbTGdjYhe3Kk4nO',0,'1995-07-04','ALUMNO',3,4,'2025-08-04','2026-04-11','AL_DIA'),(11,'Valentina','Lopez','37222999','Monroe 1890','1144441002','valentina.lopez@gmail.com','$2a$10$ekzTX7L44N9PFJ1P.dcg7.E8ZB6HzUIF/lvXKq3c7I5z/cBBtr4Bi',0,'1998-03-13','ALUMNO',3,6,'2025-09-23','2026-04-07','AL_DIA'),(12,'Nicolas','Romero','36666222','Cabildo 900','1144441003','nicolas.romero@gmail.com','$2a$10$TSjNP2M9ERQ/I7G32cJ7q.eGuEtMauZ2Ac7R1bBwjZ5YCbJASgeA2',0,'1994-01-22','ALUMNO',3,5,'2025-10-13','2026-04-13','AL_DIA'),(13,'Camila','Torres','38999123','11 de Septiembre 730','1144441004','camila.torres@gmail.com','$2a$10$.c.nlE5jFabAe2ueiMikeuMu0dQAnNDqYLVlQQA5K445535hxwjIW',0,'2000-06-18','ALUMNO',3,7,'2025-12-02','2026-04-04','AL_DIA'),(14,'Federico','Gomez','34111888','Cramer 541','1144441005','federico.gomez@gmail.com','$2a$10$HpDS/oCU/j0qX2SSUvA5s.YJQgChyKeqEulBj.m1Hq8GFRU98Xy/.',0,'1992-12-07','ALUMNO',3,6,'2025-12-27','2026-04-02','AL_DIA'),(15,'Julieta','Castro','37777999','Moldes 1640','1144441006','julieta.castro@gmail.com','$2a$10$Bd9ifF6JG/xx6Zvce5SESe44tj1TcUZkzWZbRCEbOzSkdZVGTHjeO',0,'1997-09-09','ALUMNO',3,7,'2026-01-11','2026-03-27','ADEUDA'),(16,'Bruno','Martinez','36000111','Virrey del Pino 1500','1144441007','bruno.martinez@gmail.com','$2a$10$wQGVp4zDAD8YM7TiiRXrjOlxYs.i6NSJHW65O5fOXnpZsKDno3hEG',0,'1993-11-01','ALUMNO',3,4,'2025-06-05','2026-04-15','AL_DIA'),(17,'Agustina','Ruiz','39555222','Arcos 2010','1144441008','agustina.ruiz@gmail.com','$2a$10$r5PrlqyTal/lu4tPcl9yj.rG0GwbAPS1vg5IWdo5L6Jk9dXGw70Be',0,'2001-04-26','ALUMNO',3,5,'2026-01-31','2026-03-30','ADEUDA');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'fitexa'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-01  2:00:00
